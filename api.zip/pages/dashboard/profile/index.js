/** @format */

import React from "react"

import Content from "../../../screen/dashboard/components/profile"
// import Header from "../../components/Layouts/MainHeader";

function profile(props) {
  return (
    <>
      <Content props={props} />
    </>
  )
}

export default profile

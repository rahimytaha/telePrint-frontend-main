/** @format */

import React from "react"

import Content from "../../../screen/dashboard/components/order"
// import Header from "../../components/Layouts/MainHeader";

function order(props) {
  return (
    <>
      <Content props={props} />
    </>
  )
}

export default order

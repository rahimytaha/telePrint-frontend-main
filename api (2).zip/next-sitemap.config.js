module.exports = {
  siteUrl: "https://druck-teleprint.at",
  generateRobotsTxt: true,
  sitemapSize: 7000,
  outDir: "./public",
  exclude: ["/dashboard/*", "/cart/*"]
}

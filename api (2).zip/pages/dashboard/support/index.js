/** @format */

import React from "react"

import Content from "../../../screen/dashboard/components/support"
// import Header from "../../components/Layouts/MainHeader";

function order(props) {
  return (
    <>
      <Content props={props} />
    </>
  )
}

export default order

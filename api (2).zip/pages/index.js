/* eslint-disable @next/next/no-sync-scripts */
/** @format */
import Home from "../components/home"

export default function Index() {
  return <Home />
}

/** @format */

import React from "react"

import Content from "../../../screen/dashboard/components/address"
// import Header from "../../components/Layouts/MainHeader";

function dashboard(props) {
  return (
    <>
      <Content props={props} />
    </>
  )
}

export default dashboard

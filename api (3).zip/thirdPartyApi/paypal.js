/** @format */

paypal.configure({
  mode: "sandbox", // Set to 'sandbox' for testing or 'live' for production
  client_id: "Af4wFhhRkGZE1WZ4F_g49Bw6A1r94Y_o4xlCszm7e6KXMxX_sFefUp1lVS4hdUhelCh-cCvj_VSTwBI4",
  client_secret: "YOUR_CLIENT_SECRET",
});

export default paypal;
